const express = require('express');
const app = express();
const cors = require("cors");
app.use(cors({origin: 'http://localhost:3000' }));

const memorija = require('./mr/routes/mr.routes');
var bodyParser = require('body-parser');

app.use(bodyParser.json());
app.use('/', memorija);
app.listen(8000, () => {
  console.log("SERVER RADI");
});

